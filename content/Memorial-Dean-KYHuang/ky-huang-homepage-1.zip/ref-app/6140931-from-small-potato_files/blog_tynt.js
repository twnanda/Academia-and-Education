if(document.location.protocol=='http:'){
 var Tynt=Tynt||[];Tynt.push('d0ItWgOmSr4iuRadbi-bpO');Tynt.i={"st":true,"ap":"�X�B:"};
 (function(){var s=document.createElement('script');s.async="async";s.type="text/javascript";s.src='http://tcr.tynt.com/ti.js';var h=document.getElementsByTagName('script')[0];h.parentNode.insertBefore(s,h);})();
}